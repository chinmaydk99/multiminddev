#!/usr/bin/env python3
"""
Simple test script for SFT training to debug issues
"""

from transformers import (
    AutoTokenizer, 
    AutoModelForCausalLM, 
    TrainingArguments
)
from trl import SFTTrainer
from datasets import Dataset
import torch

# Test data
train_data = [
    {"text": "__global__ void add(float* a, float* b, float* c, int n) { int i = blockIdx.x * blockDim.x + threadIdx.x; if (i < n) c[i] = a[i] + b[i]; }"}
]

# Create dataset
train_dataset = Dataset.from_list(train_data)

print("Loading model...")
tokenizer = AutoTokenizer.from_pretrained("Qwen/Qwen2.5-Coder-7B-Instruct")
model = AutoModelForCausalLM.from_pretrained(
    "Qwen/Qwen2.5-Coder-7B-Instruct",
    torch_dtype=torch.float16,
    device_map="auto"
)

if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token

print("Setting up training args...")
training_args = TrainingArguments(
    output_dir="./test-sft",
    per_device_train_batch_size=1,
    num_train_epochs=1,
    logging_steps=1,
    save_steps=10,
    eval_strategy="no",  # Disable evaluation for simplicity
)

print("Initializing SFTTrainer...")
try:
    trainer = SFTTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
    )
    print("✅ SFTTrainer initialized successfully!")
    
    print("Starting training...")
    trainer.train()
    print("✅ Training completed successfully!")
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()