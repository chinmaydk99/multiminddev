This folder is reserved for unit tests (instead of end-to-end tests) that require multiple GPUs.
